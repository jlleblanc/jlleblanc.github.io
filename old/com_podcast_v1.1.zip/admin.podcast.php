<?php

// Podcast component, based on the syndicate component from Mambo core
// Portions copyright (C) 2000 - 2005 Miro International Pty Ltd
// GNU/GPL licence

defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

global $mosConfig_absolute_path, $database;

$cid = mosGetParam($_REQUEST, 'cid', array(''));
$file = $cid[0];

require_once( $mainframe->getPath( 'admin_html' ) );
require_once( $mainframe->getPath( 'class' ) );

        $query = "SELECT a.id"
        . "\n FROM #__components AS a"
        . "\n WHERE a.option = '$option'"
        ;
        $database->setQuery( $query );
        $compid = $database->loadResult();

        // load the row from the db table
        $row = new mosComponent( $database );
        $row->load( $compid );

        // get params definitions
        $params =& new mosParameters( $row->params, $mainframe->getPath( 'com_xml', $row->option ), 'component' );

// check to see if podcast Mambot is installed and published.
$mambot = null;
$database->SetQuery("SELECT * FROM #__mambots WHERE element = 'podcast'");
$database->loadObject($mambot);

HTML_podcast::podcastWarning($option, $mambot, $params);

switch( $act )
{
	case "publishmambot":
	publishMambot($option);
	break;
	
	case "clips":
	switch ( $task )
	{
		case "upload":
		break;

		case "save":
		saveClip($option, $params);
		break;

		case "new":
		editClip($option, "", $params);
		break;

		case "edit":
		case "publish":
		editClip($option, $file, $params);
		break;

		case "help":
		mosRedirect("index2.php?option=$option&act=info");
		break;

		default:
		listClips($option, $params);
		break;
	}
	break;

	case "settings":
	switch( $task )
	{
		case "save":
		SaveSettings( $option, $params);
		break;

		case "cancel":
		mosRedirect("index2.php?option=$option");
		break;

		default:
		ShowSettings($option, $params, $compid);
		break;

	}
	break;

	case "info":
	{
		include($mosConfig_absolute_path . "/administrator/components/com_podcast/" . "info.podcast.php");
	}
	break;

	case "feeds":
	listFeeds($params);
	break;

	default:
	switch ( $task )
	{
		default:
		listClips($option, $params);
		break;
	}
	break;
}

function iTunesCats()
{
	return array(
		'Arts' => array(
			'Design',
			'Fashion & Beauty',
			'Food',
			'Literature',
			'Performing Arts',
			'Visual Arts',
		),
		'Business' => array(
			'Business News',
			'Careers',
			'Investing',
			'Management & Marketing',
			'Shopping',
		),
		'Comedy' => array(
		),
		'Education' => array(
			'Education Technology',
			'Higher Education',
			'K-12',
			'Language Courses',
			'Training',
		),
		'Games & Hobbies' => array(
			'Automotive',
			'Aviation',
			'Hobbies',
			'Other Games',
			'Video Games',
		),
		'Government & Organizations' => array(
			'Local',
			'National',
			'Non-Profit',
			'Regional',
		),
		'Health' => array(
			'Alternative Health',
			'Fitness & Nutrition',
			'Self-Help',
			'Sexuality',
		),
		'Kids & Family' => array(
		),
		'Music' => array(
		),
		'News & Politics' => array(
		),
		'Religion & Spirituality' => array(
			'Buddhism',
			'Christianity',
			'Hinduism',
			'Islam',
			'Judaism',
			'Other',
			'Spirituality',
		),
		'Science & Medicine' => array(
			'Medicine',
			'Natural Sciences',
			'Social Sciences',
		),
		'Society & Culture' => array(
			'History',
			'Personal Journals',
			'Philosophy',
			'Places & Travel',
		),
		'Sports & Recreation' => array(
			'Amateur',
			'College & High School',
			'Outdoor',
			'Professional',
		),
		'Technology' => array(
			'Gadgets',
			'Tech News',
			'Podcasting',
			'Software How-To',
		),
		'TV & Film' => array(
		),
	);
}

function makeCatDrop($name, $selected = '')
{
	$cats = iTunesCats();
	
	$dropArray = array();
	
	foreach($cats as $cat => $cs)
	{
		$dropArray[] = $cat;
		if(count($cs))
		{
			foreach($cs as $c)
			{
				$dropArray[] = $cat . ' > ' . $c;
			}
		}	
	}
	
	return mosHTML::selectList($dropArray, $name, '', $selected, $selected, true);
}

function saveClip($option, &$params)
{
	global $database;
	

	$row = new mosContent($database);
	
	// bind it to the table
	if (!$row -> bind($_POST)) {
		echo "<script> alert('"
			.$row -> getError()
			."'); window.history.go(-1); </script>\n";
		exit();
	}
	
	if(!$row->id)
		$row->created = date("Y-m-d H:m:s");
	
	if(!$row->publish_up)
		$row->publish_up = date("Y-m-d H:m:s");
	
	// store it in the db
	if (!$row -> store()) {
		echo "<script> alert('"
			.$row -> getError()
			."'); window.history.go(-1); </script>\n";
		exit();	
	}
	
	$content_id = $row->id; // save content_id
	
	$row = new Podcast($database);

	// bind it to the table
	if (!$row -> bind($_POST)) {
		echo "<script> alert('"
			.$row -> getError()
			."'); window.history.go(-1); </script>\n";
		exit();
	}	

	$row->article_id = $content_id;
	
	// store it in the db
	if (!$row -> store()) {
		echo "<script> alert('"
			.$row -> getError()
			."'); window.history.go(-1); </script>\n";
		exit();	
	}

	mosRedirect("index2.php?option=$option", "Clip information saved.");
}

function editClip($option, $file, &$params)
{
	global $database, $task;
	
	$database->SetQuery("SELECT * FROM #__content AS c LEFT JOIN #__podcast AS p ON p.article_id = c.id\n"
						." WHERE c.introtext LIKE '%{enclose ". $file ."}%' AND c.state >= 0\n"
						." ORDER BY c.state DESC");
	$database->loadObject($row);

	$newRec = false;
	$sectionid = $row->sectionid;
	
	if(!$row)
		$newRec = true;
	
	if(!$newRec)
		if(!stristr($row->introtext, "{enclose " . $file . "}"))
			$row->introtext .= "<BR>{enclose " . $file . "}";

	$javascript = "onchange=\"changeDynaList( 'catid', sectioncategories, document.adminForm.sectionid.options[document.adminForm.sectionid.selectedIndex].value, 0, 0);\"";	

	if ( $sectionid == 0 ) {
		$where = "\n WHERE section NOT LIKE '%com_%'";
	} else {
		$where = "\n WHERE section = '$sectionid'";
	}
			
	if ($row->sectionid){
		$query = "SELECT name"
		. "\n FROM #__sections"
		. "\n WHERE id = $sectionid"
		;
		$database->setQuery( $query );
		$section = $database->loadResult();
		$contentSection = $section;
	} else {
		$query = "SELECT name"
		. "\n FROM #__sections"
		. "\n WHERE id = $sectionid"
		;
		$database->setQuery( $query );
		$section = $database->loadResult();
		$contentSection = $section;
	}

	$query = "SELECT s.id, s.title"
	. "\n FROM #__sections AS s"
	. "\n ORDER BY s.ordering";
	$database->setQuery( $query );
	if ( $sectionid == 0 ) {
		$sections[] = mosHTML::makeOption( '-1', 'Select Section', 'id', 'title' );
		$sections = array_merge( $sections, $database->loadObjectList() );
		$lists['sectionid'] = mosHTML::selectList( $sections, 'sectionid', 'class="inputbox" size="1" '. $javascript, 'id', 'title' );
	} else {
		$sections = $database->loadObjectList();
		$lists['sectionid'] = mosHTML::selectList( $sections, 'sectionid', 'class="inputbox" size="1" '. $javascript, 'id', 'title', intval( $row->sectionid ) );
	}

	$sections = $database->loadObjectList();

	$sectioncategories 			= array();
	$sectioncategories[-1] 		= array();
	$sectioncategories[-1][] 	= mosHTML::makeOption( '-1', 'Select Category', 'id', 'name' );
	foreach($sections as $section) {
		$sectioncategories[$section->id] = array();
		$query = "SELECT id, name"
		. "\n FROM #__categories"
		. "\n WHERE section = '$section->id'"
		. "\n ORDER BY ordering"
		;
		$database->setQuery( $query );
		$rows2 = $database->loadObjectList();
		foreach($rows2 as $row2) {
			$sectioncategories[$section->id][] = mosHTML::makeOption( $row2->id, $row2->name, 'id', 'name' );
		}
	}

 	// get list of categories
  	if ( !$row->catid && !$row->sectionid ) {
 		$categories[] 		= mosHTML::makeOption( '-1', 'Select Category', 'id', 'name' );
 		$lists['catid'] 	= mosHTML::selectList( $categories, 'catid', 'class="inputbox" size="1"', 'id', 'name' );
  	} else {
 		$query = "SELECT id, name"
 		. "\n FROM #__categories"
 		. $where
 		. "\n ORDER BY ordering"
 		;
 		$database->setQuery( $query );
 		$categories[] 		= mosHTML::makeOption( '-1', 'Select Category', 'id', 'name' );
 		$categories 		= array_merge( $categories, $database->loadObjectList() );
 		$lists['catid'] 	= mosHTML::selectList( $categories, 'catid', 'class="inputbox" size="1"', 'id', 'name', intval( $row->catid ) );
  	}

	$fileInfo = getMP3Info($file);

	if(!strlen($row->title))
		$row->title = $fileInfo['title'];
	
	if(!strlen($row->itDuration))
		$row->itDuration = $fileInfo['duration'];

	if(!strlen($row->itSubtitle))
		$row->itSubtitle = $fileInfo['subtitle'];
		
	HTML_podcast::editClip($option, $row, $task, $sectioncategories, $contentSection, $file, $params, $lists, $fileInfo);
}

function getMP3Info($file)
{
	global $mosConfig_absolute_path;	

	$vitalInfo = array(
		'title' => '',
		'subtitle' => '',
		'duration' => '',
	);
	
	if(stristr($file, 'mp3'))
	{
		define('GETID3_HELPERAPPSDIR', $mosConfig_absolute_path . '/administrator/components/com_podcast');
		include('getid3.php');

		$getID3 = new getID3;
		$fileInfo = $getID3->analyze($mosConfig_absolute_path . '/images/stories/' .$file);

		$vitalInfo['title'] = $fileInfo['tags_html']['id3v1']['title'][0];
		$vitalInfo['subtitle'] = $fileInfo['tags_html']['id3v1']['album'][0];
		$vitalInfo['duration'] = $fileInfo['playtime_string'];
	}
		
	return $vitalInfo;
}

function publishMambot($option)
{
	global $database;
	
	$database->SetQuery("UPDATE #__mambots SET published = '1' WHERE element = 'podcast'");
	$database->Query();
	
	mosRedirect("index2.php?option=" . $option, "Podcast mambot published.");
}

function listClips($option, &$params)
{
	global $mosConfig_absolute_path, $mosConfig_list_limit, $database, $mainframe;

	$limit 	= $mainframe->getUserStateFromRequest( "viewlistlimit", 'limit', $mosConfig_list_limit );
	$limitstart = $mainframe->getUserStateFromRequest( "view{$option}limitstart", 'limitstart', 0 );

	$mediapath = $params->def( 'mediapath', 'images/stories' );

	$clipdir = opendir($mosConfig_absolute_path . '/' . $mediapath);
	
	$files = array();
	$filename = "";
	while (false !== ($filename = readdir($clipdir))) {
		if($filename == ".." || $filename == ".") continue;
		if(is_dir($mosConfig_absolute_path . '/' . $mediapath . '/' . $filename)) continue;
		$files[] = $filename;
	}

	require_once( $mosConfig_absolute_path . '/administrator/includes/pageNavigation.php' );
	$pageNav = new mosPageNav( count($files), $limitstart, $limit  );

	$files = array_slice($files, $pageNav->limitstart, $pageNav->limit);	

	HTML_podcast::listClips($option, $files, $pageNav, $params);
}

function ShowSettings( $option, &$params, $id ) {
        global $database, $mainframe, $mosConfig_list_limit;

        HTML_podcast::settings( $option, $params, $id );
}

function SaveSettings( $option ) {
        global $database;

        $params = mosGetParam( $_REQUEST, 'params', '' );
        if (is_array( $params )) {
            $txt = array();
            foreach ($params as $k=>$v) {
                $txt[] = "$k=$v";
                }
                $_REQUEST['params'] = mosParameters::textareaHandling( $txt );
        }

        $row = new mosComponent( $database );
//      $database->setQuery("SELECT * FROM #__components WHERE link = 'option=com_podcast'");
//      $database->loadObject($row);

        if (!$row->bind( $_REQUEST )) {
                echo "<script> alert('".$row->getError()."'); window.history.go(-1); </script>\n";
                exit();
        }

        if (!$row->check()) {
                echo "<script> alert('".$row->getError()."'); window.history.go(-1); </script>\n";
                exit();
        }
        if (!$row->store()) {
                echo "<script> alert('".$row->getError()."'); window.history.go(-1); </script>\n";
                exit();
        }

        $msg = 'Settings successfully Saved';
        mosRedirect( 'index2.php?option='. $option, $msg);
}

function listFeeds(&$params)
{
	global $database;
	
	$q = "select C.id, C.title catTitle, C.section, C.ordering, S.title secTitle from #__categories C left join #__sections S on C.section = S.id where C.published = '1' order by C.section, C.ordering";
	
	$database->setQuery($q);
	$categories = $database->loadObjectList();

	HTML_podcast::feeds( $option, $categories, $params );
}

?>
