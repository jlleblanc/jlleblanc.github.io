<?php

global $option;

?>

<style>
.podcastheader{
	font-family: Georgia, serif;
	font-size: 18pt;
	color: #333333;
}

.divider {
	border: 1px dotted #000000;
}

.podcastmessage {
	text-align: left;
	font-family: Tahoma, Arial, serif;
	font-size: 12pt;
}

</style>

<div class="podcastheader">Joomla Podcasting Component - Version 1.1</div>
<div class="divider"></div>
<div class="podcastmessage">
Thank you for installing this component! Be sure to install the accompanying module and plugin. While <a href="mailto:contact@jlleblanc.com?subject=Podcast Component Feedback">feedback</a> is greatly appreciated, please read to the end of this document before sending in bug reports. You can also <a href="http://www.jlleblanc.com/option,com_joomlaboard/Itemid,62/">browse the forums</a> for answers to frequently asked questions.<br /><br />
</div>


<br />
<div class="podcastheader">What to expect</div>
<div class="divider"></div>
<div class="podcastmessage">

When you select Podcast &gt; Manage Clips from the components menu, you will be presented with a list of all the files in the folder being used for podcasts (default is images/stories, this can be changed through the <a href="index2.php?option=com_podcast&act=settings">settings</a>). The middle column gives you the tag to use to include a certain file within an article. The published column shows if this tag appears within any article in the system. To add files to the folder, use FTP as Media Manager usually cannot handle large MP3s.
<br /><br />

The [Publish within an article] links currently point to pages where you can edit show notes and add iTunes-specific information.
<br /><br />

If you want to include a file from an external server, use a tag like this: {enclose http://www.otherserver.com/file23.mp3 8474349 audio/mpeg } . The first parameter is the filename, the second is the file length in bytes, and the third is the encoding type.
<br /><br />

Before using the podcast component, change the configuration settings by clicking <a href="index2.php?option=com_podcast&act=settings">here</a>.
<br /><br />

This software is based on code from Joomla's core syndication component.
</div>

<br />
<div class="podcastheader">Known issues:</div>
<div class="divider"></div>
<div class="podcastmessage">
<b>I am currently aware of the following issues. If you find reasonable ways to fix these, please send me an <a href="mailto:contact@jlleblanc.com?subject=Solutions for podcasting issues">e-mail</a>.</b>
<li>There are character encoding issues. Currently (as of version 1.0.11), Joomla does not have full support for UTF-8, while iTunes prefers UTF-8 encoded feeds. If you run into issues, go to the <a href="index2.php?option=com_podcast&act=settings">settings panel</a> and change the encoding to your preferred character set.</li>
<li><b>Feeds do not always validate.</b> Thanks to everyone who sent me links to feedvalidator.org. Unfortunately, Apple's specifications currently break feed validation. </li>
<br />
</div>

<div class="podcastheader">Features under consideration:</div>
<div class="divider"></div>
<div class="podcastmessage">
<li>In browser FTP uploads: This will require functionality found in Joomla 1.5. I will wait until this becomes available before implementing it.</li>
<br />
</div>

<div class="podcastheader">Credits</div>
<div class="divider"></div>
<div class="podcastmessage">
The following projects released under GPL were used in the creation of the suite:<br />
<li><b><a href="http://phpclasses.spyral-productions.com/browse/package/1486.html">ID3 Tag Reader</a></b> - Tadeu Oliveira</li>
<li><b><a href="http://www.ericzhang.com/mp3.php">Simple Flash MP3 Player</a></b> - Eric Zhang</li>
<br /><br />
<div class="podcastmessage">
</div>
