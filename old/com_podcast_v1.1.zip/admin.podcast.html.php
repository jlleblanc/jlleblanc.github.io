<?php 
 
// Podcast component, based on the syndicate component from Mambo core 
// Portions copyright (C) 2000 - 2005 Miro International Pty Ltd 
// GNU/GPL licence 
 
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' ); 
 
require_once( $mainframe->getPath( 'admin_html' ) ); 
 
class HTML_podcast { 
 
function podcastWarning($option, &$mambot, &$params) 
{ 
	global $mosConfig_live_site, $act; 
	 
	?> 
	<style> 
	.warning { 
		background: #FFFF99; 
		color: #000000; 
		font-size: 11pt; 
		font-family: Tahoma, serif; 
		border: 1px dotted #CCCC00; 
		padding: 10px; 
		margin-bottom: 10px; 
		text-align: left; 
	} 
	</style> 
	<?php 
	 
	if($mambot->id == 0 && $mambot->published == 0) 
	{ 
		// not installed 
		?> 
		<div class="warning"> 
		<B>Alert:</B><BR> 
		To properly set up the feed, please <a href="http://www.jlleblanc.com/blogcategory/0/">download</a>, <a href="index2.php?option=com_installer&element=mambot">install</a>, and publish the podcast mambot. 
		</div> 
		<?php 
	} else if ($mambot->published == 0) { 
		// installed, but not published. 
		?> 
		<div class="warning"> 
		<B>Alert:</B><BR> 
		Please <a href="index2.php?option=<?php echo $option; ?>&act=publishmambot">publish</a> the podcast mambot so that the feed can be properly built. 
		</div> 
		<?php 
	} 
	 
} // mambotWarning 
 
function editClip($option, &$row, $task, &$sectioncategories, &$sections, $file, &$params, &$lists, &$fileInfo) 
{ 
	$linktitle = $params->get('linktitle', 'Listen Now!'); 
	 
	mosCommonHTML::loadCalendar(); // for publish date 
	 
	?> 
	<script language="javascript" type="text/javascript"> 

	<!--
	var sectioncategories = new Array;
	<?php
	$i = 0;
	foreach ($sectioncategories as $k=>$items) {
		foreach ($items as $v) {
			echo "sectioncategories[".$i++."] = new Array( '$k','".addslashes( $v->id )."','".addslashes( $v->name )."' );\n\t\t";
		}
	}

	?>
	function submitbutton(pressbutton) { 
		<?php getEditorContents( 'editor', 'introtext' ); ?>

		if (pressbutton == 'cancel') {
			submitform( pressbutton );
			return;
		}
			
		if (document.adminForm.title.value == '' && pressbutton == 'save') { 
			alert('Please add a title.'); 
		} else if (document.adminForm.sectionid.value == "-1"){
			alert( "You must select a Section." );
		} else if (document.adminForm.catid.value == "-1"){
			alert( "You must select a Category." );
 		} else if (document.adminForm.catid.value == ""){
 			alert( "You must select a Category." );
		} else { 
			submitform( pressbutton ); 
		} 
	}
       	//-->	
	</script> 
<?php  
if($params->get('hidehelps', 0) == 0) 
{ 
?> 
	<style> 
	.alert { 
		color: #000000; 
		font-size: 11pt; 
		font-family: Tahoma, serif; 
		text-align: left; 
		padding: 10px; 
		margin-bottom: 5px; 
		background: #CCDDFF; 
		border: 1px #336699 dotted; 
	} 
	</style> 
	<div class="alert">The tag {enclose <?php echo $file; ?>} will be changed into a link titled "<?php echo $linktitle ?>"<BR> This tag is necessary for building the feed.</div> 
<?php 
} 
?> 
 
	<form action="index2.php" method="post" name="adminForm"> 
	 
	<table width="100%"> 
 
	<?php 
	// PHP 5 property-of-non-object issue 
	 
	if(isset($row->introtext)) 
		$introtext = $row->introtext; 
	else 
		$introtext = "{enclose $file}"; 
	 
	?> 
	 
	<tr><td valign="top">Title: </td><td valign="top"><input class="text_area" name="title" value="<?php echo $row->title; ?>" /></td></tr>
	<tr><td valign="top">Section: </td><td valign="top"><?php echo $lists['sectionid']; ?></td></tr>
	<tr><td valign="top">Category: </td><td valign="top"><?php echo $lists['catid']; ?></td></tr> 
	<tr><td valign="top">Show Notes: </td><td valign="top"><?php editorArea( 'editor',  $introtext, 'introtext', '500px;', '200', '3', '30' ) ; ?></td></tr> 
	<tr><td valign="top">Published: </td><td valign="top"> 
	<select name="state">
	<?php 
	 
	if($row->state == 0 && $row->id != 0) 
	{ 
		echo "<option value=\"1\">Yes</option>"; 
		echo "<option value=\"0\" selected>No</option>"; 
	} else { 
		echo "<option value=\"1\" selected>Yes</option>"; 
		echo "<option value=\"0\">No</option>"; 
	} 
	 
	?> 
	</select> 
	</td></tr> 
	 
	<tr> 
	<td>&nbsp;</td> 
	</tr> 
	<tr> 
	<td>Publish Date:</td> 
	<td> 
	<input class="text_area" type="text" name="publish_up" id="publish_up" size="25" maxlength="19" value="<?php echo $row->publish_up; ?>" /> 
	<input type="reset" class="button" value="..." onClick="return showCalendar('publish_up', 'y-mm-dd');"> 
	</td></tr> 
	 
	<?php 
	// PHP 5 property-of-non-object issue 
	if(isset($row->itBlock)) 
		$itBlock = $row->itBlock; 
	else 
		$itBlock = null; 
		 
	if(isset($row->itExplicit)) 
		$itExplicit = $row->itExplicit; 
	else 
		$itExplicit = null; 
	 
	?> 
	 
	<tr><td>iTunes: Block</td><td><?php echo mosHTML::yesnoSelectList('itBlock', '', $itBlock); ?></td></tr> 
	<tr><td>iTunes: Duration</td><td><input class="text_area" name="itDuration" value="<?php echo $row->itDuration; ?>" /></td></tr> 
	<tr><td>iTunes: Explicit</td><td><?php echo mosHTML::yesnoSelectList('itExplicit', '', $itExplicit); ?></td></tr> 
	<tr><td>iTunes: Keywords</td><td><input class="text_area" name="itKeywords" value="<?php echo $row->itKeywords; ?>" /></td></tr> 
	<tr><td>iTunes: Subtitle</td><td><input class="text_area" name="itSubtitle" value="<?php echo $row->itSubtitle; ?>" /></td></tr> 
	</table> 
	 
	 
	<input type="hidden" name="option" value="<?php echo $option; ?>" /> 
	<input type="hidden" name="task" value="" /> 
	<input type="hidden" name="act" value="clips" /> 
	<input type="hidden" name="id" value="<?php echo $row->id; ?>" /> 
	<input type="hidden" name="podcast_id" value="<?php echo $row->podcast_id; ?>" /> 
	<input type="hidden" name="boxchecked" value="0" /> 
	</form>  
	<?php 
} // editClip 
 
function listClips($option, &$files, &$pageNav, &$params) 
{ 
	global $mosConfig_absolute_path; 
	 
	$mediapath = $params->get('mediapath', 'images/stories'); 
?> 
<script language="javascript" type="text/javascript"> 
	function submitbutton(pressbutton) { 
		if(pressbutton == 'unpublish') 
		{ 
			if(confirm('Unpublishing files may disrupt the feed. Are you sure you wish to continue unpublishing? (Files will not be removed.)')){ 
				submitform( pressbutton ); 
			} 
		} else { 
			submitform( pressbutton ); 
		} 
	} 
</script> 
 
<?php  
if($params->get('hidehelps', 0) == 0) 
{ 
?> 
	<style> 
	.alert { 
		color: #000000; 
		font-size: 11pt; 
		font-family: Tahoma, serif; 
		text-align: left; 
		padding: 10px; 
		margin-bottom: 5px; 
		background: #CCDDFF; 
		border: 1px #336699 dotted; 
	} 
	</style> 
	<div class="alert">To add one of the files below to your podcast, click on the filename to create an article. <BR><BR>Files in the directory <?php echo $mosConfig_absolute_path . "/" . $mediapath; ?> are listed. To add new files, use an FTP client. You can use another directory instead by adjusting the <a href="index2.php?option=<?php echo $option ?>&act=settings">settings</a>.</div> 
<?php 
} 
?> 
 
<form action="index2.php" method="post" name="adminForm"> 
<table cellpadding="4" cellspacing="0" border="0" width="100%" class="adminlist"> 
<tr> 
<th class="title"><input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count($files); ?>);" /></th> 
<th class="title">Filename</th> 
<th class="title">Tag</th> 
<th class="title">Found in Article</th> 
<th class="title">Article Published</th> 
</tr> 
<?php 
	$k = 0; 
 
	if(count($files)) 
	{ 
		$i = 0; 
		foreach($files as $file) 
		{ 
			//if(eregi('{enclose ' . $file . '}', $allcontent)) $pub = true; 
			 
			$filerow = null; 
 
			?><tr class="<?php echo "row$k"; ?>"> 
			<td><input type="checkbox" id="cb<?php echo $i;?>" name="cid[]" value="<?php echo $file; ?>" onclick="isChecked(this.checked);" /></td> 
			<td><a href="#edit" onclick="return listItemTask('cb<?php echo $i;?>','edit')"><?php echo $file; ?></a></td> 
			<td>{enclose <?php echo $file; ?>}</td> 
			<td><?php  
			 
			// found in an article? 
			global $database; 
			$database->SetQuery("SELECT * FROM #__content WHERE (introtext LIKE '%{enclose $file}%' OR `fulltext` LIKE '%{enclose $file}%') AND state >= 0 ORDER BY state DESC"); // didn't like this snippet: OR fulltext LIKE '%{enclose $file}%' 
			$filerows = $database->loadObjectList(); 
			 
			if(count($filerows)) 
				$filerow = $filerows[0]; 
			else 
				$filerow = null; 
			 
			if(isset($filerow->id)){ 
				if($filerow->id != 0) 
					echo "<img src=\"images/tick.png\" border=\"0\">"; 
				else  
					echo "<a href=\"javascript: void(0);\" onClick=\"return listItemTask('cb$i','publish')\">[Publish within an article]</a>"; 
			} else { 
				echo "<a href=\"javascript: void(0);\" onClick=\"return listItemTask('cb$i','publish')\">[Publish within an article]</a>"; 
			} 
					 ?></td> 
			 
			<td> 
			<?php 
				if(isset($filerow->state)) 
				{ 
					if($filerow->state == 1) 
						echo "<img src=\"images/tick.png\" border=\"0\">"; 
					else 
						echo "<img src=\"images/publish_x.png\" border=\"0\">"; 
				} else { 
					echo "<img src=\"images/publish_x.png\" border=\"0\">"; 
				} 
				 
				if(count($filerows) > 1) 
				{ 
					echo "&nbsp;(file found in " . count($filerows) . " articles)"; 
				} 
			?> 
			</td> 
			 
			</tr><?php 
 
			$k = 1 - $k; 
			$i++; 
		} 
	} 
 
?> 
</table> 
		<?php echo $pageNav->getListFooter(); ?> 
<input type="hidden" name="option" value="<?php echo $option; ?>" /> 
<input type="hidden" name="task" value="" /> 
<input type="hidden" name="act" value="clips" /> 
<input type="hidden" name="boxchecked" value="0" /> 
</form>  
<?php 
 
} // listClips 
 
 
function settings( $option, $params, $id ) 
{ 
	global $mosConfig_live_site; 
 
	?> 
 
<div id="overDiv" style="position:absolute; visibility:hidden; z-index:10000;"></div> 
<form action="index2.php" method="post" name="adminForm"> 
        <table class="adminform"> 
           <tr> 
               <th> 
               Podcast Settings 
               </th> 
           </tr> 
 
	<tr> 
	<td> 
	<?php 
 
	echo $params->render(); 
 
	?> 
	</td> 
	</tr> 
	</table> 
 
 
 
<input type="hidden" name="option" value="<?php echo $option; ?>" /> 
<input type="hidden" name="task" value="" /> 
<input type="hidden" name="act" value="settings" /> 
<input type="hidden" name="boxchecked" value="0" /> 
 
<input type="hidden" name="id" value="<?php echo $id; ?>" /> 
 
</form> 
<script language="Javascript" src="<?php echo $mosConfig_live_site;?>/includes/js/overlib_mini.js"></script> 
 
	<?php 
 
} // settings 

function feeds( $option, &$categories, &$params )
{
	global $mosConfig_live_site;

	if($params->get('hidehelps', 0) == 0)
	{
	?>
	<style>
	.alert {
		color: #000000;
		font-size: 11pt;
		font-family: Tahoma, serif;
		text-align: left;
		padding: 10px;
		margin-bottom: 5px;
		background: #CCDDFF;
		border: 1px #336699 dotted;
	}
	</style>
	<div class="alert">Below are podcast links for every published category of your site. Use these if you want to allow your visitors to listen to certain series of your episodes. For instance, you have a podcast about cooking, but have separate categories for dinners and desserts. By providing your visitors with a link to desserts, they can skip dinner. Your main podcast feed will have all episodes.</div>
	<?php
	}
	
	?>
	<table class="adminlist">
	<?php
	
	foreach($categories as $cat)
	{
		echo '<tr><td><h2><a href="'.$mosConfig_live_site.'/index2.php?option=com_podcast&feed=RSS2.0&no_html=1&catID='. $cat->id .'">' . $cat->secTitle . ' / ' . $cat->catTitle . '</a></h2></td></tr>';
	}
	
	?>
	</table>
	<?php

} // feeds

} // class 
 
?> 
