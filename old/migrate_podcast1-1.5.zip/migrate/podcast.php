<?php

class Podcast_ETL extends ETLPlugin {
	
	var $ignorefieldlist = array('article_id');
	var $valuesmap = array('filename');
	var $newfieldlist = array('filename');
	
	function getName() { return "Podcast Data ETL Plugin"; }
	function getAssociatedTable() { return 'podcast'; }
	
	function mapvalues($key,$value) {
		switch($key) {
			case 'filename':
				$value = podcastGetFilename($this->_currentRecord['article_id']);
				return $value;
				break;
			
			default:
				return $value;
				break;
		}
	}
	
	function getSQLPrologue() {
		return "# Start of Podcasts\n";
	}
	
	function getSQLEpilogue() {
		return "# End of Podcasts\n";
	}
}

function podcastGetFilename($article_id)
{
	global $database;
	
	$row = new mosContent($database);
	
	if (!$row->load($article_id)) {
		return '';
	}
	
	preg_match('/\{enclose\s(.*)(\s.*)?(\s.*)?\}/', $row->introtext, $matches);
	
	if (isset($matches[1])) {
		return $matches[1];
	} else {
		return '';
	}
}