<?
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' ); 

class HTML_joeDailyMessage{

function edit( $option, &$row ) {
?>

<form action="index2.php" method="post" name="adminForm" id="adminForm" class="adminForm">
<table border="0" cellpadding="3" cellspacing="0">

<tr>
<td>Message: </td>
<td><input type="text" size="50" maxsize="100" name="message" value="<?php echo $row->message; ?>" /></td>
</tr>

<tr>
<td>Date: </td>
<td><input size="30" name="date" value="<? echo $row->date; ?>"></td>
</tr>

<tr>
<td>Published: </td>
<td><? echo mosHTML::yesnoSelectList( "published", "", $row->published ); ?></td>
</tr>

</table>
<input type="hidden" name="id" value="<?php echo $row->id; ?>" />
<input type="hidden" name="option" value="<?php echo $option; ?>" />
<input type="hidden" name="task" value="" />
</form>
<? }

function listConfiguration($option, &$rows)
{
	?>
<script language="Javascript" src="js/dhtml.js"></script>

	<?
	$row = $rows[0];
	?>

<table cellpadding="4" cellspacing="0" border="0" width="100%">
<tr>
<td width="" class="tabpadding">&nbsp;</td>
<td id="tab1" class="offtab" onClick="dhtml.cycleTab(this.id)">Bold</td>
<td id="tab2" class="offtab" onClick="dhtml.cycleTab(this.id)">Italic</td>
<td id="tab3" class="offtab" onClick="dhtml.cycleTab(this.id)">Underline</td>
<td id="tab4" class="offtab" onClick="dhtml.cycleTab(this.id)">Show Date</td>
<td width="90%" class="tabpadding">&nbsp;</td>
</tr>
</table>
<form action="index2.php" method="post" name="adminForm">

<div id="page1" class="pagetext">
<center>Bold: <? echo mosHTML::yesnoSelectList( "bold", "", $row->bold ); ?></center>
</div>

<div id="page2" class="pagetext">
<center>Italic: <? echo mosHTML::yesnoSelectList( "italic", "", $row->italic ); ?></center>
</div>

<div id="page3" class="pagetext">
<center>Underline: <? echo mosHTML::yesnoSelectList( "underline", "", $row->underline ); ?></center>
</div>

<div id="page4" class="pagetext">
<center>Show Date: <? echo mosHTML::yesnoSelectList( "showdate", "", $row->showdate ); ?></center>
</div>


<input type="hidden" name="option" value="<?php echo $option; ?>" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="configid" value=<? echo $row->configid ?> />
<input type="hidden" name="act" value="configure" />

</form> 

<script language="javascript" type="text/javascript">dhtml.cycleTab('tab1');</script>

	<?
}


function listMessages( $option, &$rows ) {
�?>
<form action="index2.php" method="post" name="adminForm">
<table cellpadding="4" cellspacing="0" border="0" width="100%" class="adminlist">
<tr>
<th width="20"><input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count($rows); ?>);" /></th>
<th class="title" width="25%">Message</th>
<th>Date</th>
<th width="25%">Published</th>
</tr>

<?php
	$k = 0;
	for($i=0; $i < count( $rows ); $i++) {
	$row = $rows[$i];
�� ?>
	<tr class="<?php echo "row$k"; ?>">
	<td><input type="checkbox" id="cb<?php echo $i;?>" name="cid[]" value="<?php echo $row->id; ?>" onclick="isChecked(this.checked);" /></td>
	<td><a href="#edit" onclick="return listItemTask('cb<?php echo $i;?>','edit')"><?php echo $row->message; ?></a></td>
	<td><? echo mosFormatDate($row->date); ?></td>
	<td align="center">
����� <?php
	if ($row->published == "1") {
	echo "<a href=\"javascript: void(0);\" onClick=\"return listItemTask('cb$i','unpublish')\"><img src=\"images/publish_g.png\" border=\"0\" /></a>";
	} else {
	echo "<a href=\"javascript: void(0);\" onClick=\"return listItemTask('cb$i','publish')\"><img src=\"images/publish_x.png\" border=\"0\" /></a>";
	}
����� ?>
	</td>
	<?php $k = 1 - $k; ?>
	</tr>
<?php } 

?>
<input type="hidden" name="option" value="<?php echo $option; ?>" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
</form> 
</table>

<? } 


}

?>