<?php
function com_uninstall() {
}
?> 