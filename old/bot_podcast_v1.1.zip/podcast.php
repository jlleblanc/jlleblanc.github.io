<?php

defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

$_MAMBOTS->registerFunction( 'onPrepareContent', 'botPodcast' );

function botPodcast( $published, &$row, &$params, $page=0 ) {

	global $database, $mosConfig_live_site;

	$query = "SELECT a.id"
	. "\n FROM #__components AS a"
	. "\n WHERE a.option = 'com_podcast'"
	;
	$database->setQuery( $query );
	$id = $database->loadResult();

	// load syndication parameters
	$component = new mosComponent( $database );
	$component->load( $id );
	$pParams =& new mosParameters( $component->params );
		
	$regex = "#{enclose (.*?)}#s";
	$row->text = replaceText($row->text, &$pParams, $regex);
	$regex = "#{player (.*?)}#s";
	$row->text = replaceText($row->text, &$pParams, $regex);
	
	return true;
}

function replaceText($text, &$pParams, $regex)
{
	global $mosConfig_live_site;
	
	preg_match_all($regex, $text, $parameters);

	$types = array (
		'asf' => 'video/asf',
		'asx' => 'video/asf',
		'avi' => 'video/avi',
		'm4a' => 'audio/x-m4a',
		'm4v' => 'video/x-m4v',
		'mov' => 'video/quicktime',
		'mp3' => 'audio/mpeg',
		'mpe' => 'video/mpeg',
		'mpeg' => 'video/mpeg',
		'mpg' => 'video/mpeg',
		'ogg' => 'audio/ogg',
		'qt' => 'video/quicktime',
		'ra' => 'audio/x-realaudio',
		'ram' => 'audio/x-realaudio',
		'wav' => 'audio/wav',
		'wax' => 'video/asf',
		'wma' => 'audio/wma',
		'wmv' => 'video/wmv',
		'wmx' => 'video/asf',
	);

    foreach($parameters[1] as $par)
    {
        // get details from parameters
        $paramarray = explode(" ", $par);

		// if not an external link, add the current path

		if(!eregi('http://', $paramarray[0]) && !eregi('https://', $paramarray[0]))
		{
			$paramarray[0] = $mosConfig_live_site . "/" . $pParams->def( 'mediapath', 'images/stories' ) . "/" . $paramarray[0];
		}

		$linkhandling = $pParams->def( 'linkhandling', 'links');
		$linktitle = $pParams->def( 'linktitle', 'Listen Now!');
		$linkcode = $pParams->def( 'linkcode', '');

		if($linkhandling == 'links')
		{
			$link = '<a href="' . $paramarray[0] . '">' . $linktitle . '</a>';
		}
		else if($linkhandling == 'html')
		{
			$link = preg_replace('/\{filename\}/', $paramarray[0], $linkcode);
		}
		else if($linkhandling == 'player')
		{
			$width = $pParams->def( 'playerwidth', 150);
			$height = $pParams->def( 'playerheight', 50);
			$link .= '<embed wmode="transparent" src="' . $mosConfig_live_site . '/components/com_podcast/music.swf?url=' . $paramarray[0] . '&mode=play&autostart=false" autostart="false" mode="play" quality="high" pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="' . $width . '" height="' . $height . '">';
			$link .= '<param name="autostart" value="false">' . "\n";
			$link . '</embed>' . "\n";
		}
		else if($linkhandling == 'QTplayer')
		{
			$ext = substr($paramarray[0], strlen($paramarray[0]) - 3);

			$width = $pParams->def( 'playerwidth', 320);
			$height = $pParams->def( 'playerheight', 240);
			
			$link = '<object classid="clsid:02BF25D5-8C17-4B23-BC80-D3488ABDDC6B" width="320" height="240" codebase="http://www.apple.com/qtactivex/qtplugin.cab">';
			$link .= '<param name="src" value="' . $paramarray[0] . '" />';
			$link .= '<param name="href" value="' . $paramarray[0] . '" />';
			$link .= '<param name="scale" value="aspect" />';
			$link .= '<param name="controller" value="true" />';
			$link .= '<param name="autoplay" value="true" />';
			$link .= '<param name="bgcolor" value="000000" />';
			$link .= '<param name="pluginspage" value="http://www.apple.com/quicktime/download/" />';
			$link .= '<embed src="' . $paramarray[0] . '" width="320" height="240" scale="aspect" cache="true" bgcolor="000000" autoplay="true" controller="true" src="' . $paramarray[0] .'" type="' . $types[$ext] . '" pluginspage="http://www.apple.com/quicktime/download/"></embed>';
			$link .= '</object>';
		
		}

		// replace link
		$text = preg_replace( "#{enclose ". preg_quote($par) ."}#s", $link, $text );
    }
    
    return $text;
}


?>
