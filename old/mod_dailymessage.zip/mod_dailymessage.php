<?

defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

global $database;

$database->setQuery("SELECT * FROM #__joe_dailymessage WHERE published = '1'");

$rows = $database->loadObjectList();

foreach($rows as $row)
{
	echo $row->message . "<br>";
}


?>