<?php

global $option;

?>

<style>
.podcastheader{
	font-family: Georgia, serif;
	font-size: 18pt;
	color: #333333;
}

.divider {
	border: 1px dotted #000000;
}

.podcastmessage {
	text-align: left;
	font-family: Tahoma, Arial, serif;
	font-size: 12pt;
}

</style>

<div class="podcastheader">Mambo Podcasting Component - Beta 2</div>
<div class="divider"></div>
<div class="podcastmessage">
Thank you for installing this component! Be sure to install the accompanying module and Mambot. This is a second beta copy of the podcasting component and <a href="mailto:contact@jlleblanc.com?subject=Podcast Component Feedback">feedback</a> is greatly appreciated.<br><BR>
In the future, this component will make use of the FTP assist functionality seen in the safe mode patch components. This will allow you to upload large podcasts directly from your browser without running into file size limits.
</div>


<BR>
<div class="podcastheader">What to expect</div>
<div class="divider"></div>
<div class="podcastmessage">

When you select Podcast > Manage Clips from the components menu, you will be presented with a list of all the files in the folder being used for podcasts (default is images/stories, this can be changed through the <a href="index2.php?option=com_podcast&act=settings">settings</a>). The middle column gives you the tag to use to include a certain file within an article. The published column shows if this tag appears within any article in the system. Eventually, this will be turned into the standard "publish/unpublish" toggle which will allow you to publish a podcast complete with show notes.
<BR><BR>

If you want to include a file from an external server, use a tag like this: {enclose http://www.otherserver.com/file23.mp3 8474349 audio/mpeg } . The first parameter is the filename, the second is the file length in bytes, and the third is the encoding type.
<BR><BR>

Before using the podcast component, change the configuration settings by clicking <a href="index2.php?option=com_podcast&act=settings">here</a>.

<BR><BR>

This software is based on code from Mambo's core syndication component.
</div>

