<?
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

class menuMp3Player {

	function INFO_MENU()
	{
		mosMenuBar::startTable();
		mosMenuBar::back();
		mosMenuBar::endTable();
	}	

	function DEFAULT_MENU()
	{
		mosMenuBar::startTable();
		mosMenuBar::addNew('new');
		mosMenuBar::editList('edit', 'Edit');
		mosMenuBar::deleteList( ' ', 'delete', 'Remove' );
		mosMenuBar::endTable();
	}
	
	function EDIT_MENU()
	{
		mosMenuBar::startTable();
		mosMenuBar::save();
		mosMenuBar::cancel();
		mosMenuBar::endTable();
	}
	
	function SETTINGS_MENU()
	{
		mosMenuBar::startTable();
		mosMenuBar::save();
		mosMenuBar::endTable();
	}
	
}

?>