<?
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

class mp3Player_HTML
{
	function showInformation($option)
	{
		?>
		<div style=" text-align: left; "><h3>This component is based off of an mp3 player written in flash by Jeroen Wijering. His notes and contact information are below. The original code and .fla files can be downloaded from his website at <a href="http://www.jeroenwijering.com">www.jeroenwijering.com</a>. I created this component as a part of a larger project for Siobhan Ramsey: <a href="http://www.sandboxeducation.co.uk/">www.sandboxeducation.co.uk</a><BR><BR>-Joe</h3></div> 
		
		<div style="border-top: 1px dotted #000000; width: 100%;">&nbsp;</div>
		
<div style="text-align: left;">
		HI GUYS
<BR><BR>
thanks for downloading my flash mp3 player. the player supports various playmodes, streaming playback, playhead scrubbing, an xml playlist and an equalizer. An iPlayer skin is yet available, and creating your own skin is just a matter of changing the symbols.
<BR><BR>

INSTALLATION
<BR><BR>
insert the files and titles of the songs you want to play into the mp3player.xml file with a texteditor. Don't use spaces or special charactes in the filenames ! in the xml file you can also set:
<BR><BR>
* if the display should be open on startup. you can insert "yes" or "no".<BR>
* if the playlist should be open at startup. you can insert "yes" or "no".<BR>
* if the player should autostart at startup. you can insert "yes", "no" or "random" (to start a random song).<BR>
<BR>
if you like the look of the player, just upload the files onto your webserver. if not, it should be easy to create a new skin for the flash mp3 player by editing the symbols. just make sure you leave the script, movieclip names and nesting intact.
<BR><BR>

HINTS
<BR><BR>
the mp3 player only accepts mp3 files. support for other audio formats is impossible. also, flash doesn't support vbr (variable bit rate) mp3 files. if you play vbr mp3 files, the playback will sound like a chipmunks version of your songs. the best way to encode mp3 files is to use a fixed bitrate of 64/96/128 kbps with a sample frequency of 22.05 kHz and joint stereo. 
<BR><BR>
the player is draggable, so if you include it in a full-window flash applet, your visitors can move the player around. 
<BR><BR>
the player accepts the xml playlist as an html parameter. this way you can give one player multiple playlists, eg. with a small php script. check out the 'mp3player_vars.html' for an example. This page will load the some_other_playlist.xml file. 
<BR><BR>
Note that the xml playlists always should reside on the same website as the mp3 player (security restrictions from flash). You can, however, link to mp3 files from different websites !
<BR><BR>

CHANGES
<BR><BR>
* various bugfixes<BR>
* added playlist parameter to html<BR>
* added switches for display/playlist showing in xml<BR>
* added auto/random start switch in xml<BR>
<BR>

LICENSING
<BR><BR>
note that a creative commons license (creativecommons.org) is applied to this software. as such, you are free to copy, use, adapt and redistribute this software for non-commercial purposes, as long as you will credit me and share alike. If you plan to use this software for commercial purposes, please contact me so we can work out a suitable arrangement. the exact terms of this license can be found at my website.
<BR><BR>

GOOD LUCK
<BR><BR>
www.jeroenwijering.com<BR>
mail@jeroenwijering.com<BR>
</div>
		<?
	}

	function editSettings($option, &$params, $id)
	{
			global $mosConfig_live_site;

	?>

<div id="overDiv" style="position:absolute; visibility:hidden; z-index:10000;"></div>
<form action="index2.php" method="post" name="adminForm">
        <table class="adminform">
           <tr>
               <th>
               mp3 Player Settings
               </th>
           </tr>

	<tr>
	<td>
	<?

	echo $params->render();

	?>
	</td>
	</tr>
	</table>



<input type="hidden" name="option" value="<? echo $option; ?>" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="act" value="settings" />
<input type="hidden" name="boxchecked" value="0" />

<input type="hidden" name="id" value="<?php echo $id; ?>" />

</form>
<script language="Javascript" src="<?php echo $mosConfig_live_site;?>/includes/js/overlib_mini.js"></script>

	<?
	}
	
	
	function editClip($option, &$row)
	{
		?>
		<form action="index2.php" method="post" name="adminForm">
		<table border="0" cellpadding="3" cellspacing="0" width="100%">
		<tr><td colspan="2"><b>Adding a clip:</b> If the clip is a file on the same server as your Mambo installation, enter the filename with a relative path. For instance, if you have an mp3 named song1.mp3 in the images/stories folder, you should enter <font color="#A52A2A">images/stories/song1.mp3</font> as the filename.</td></tr>
		<tr><td>Filename or URL:</td><td><input name="mp3_filename" value="<? echo $row->mp3_filename; ?>"></td></tr>
		<tr><td>Title:</td><td><input name="mp3_title" value="<? echo $row->mp3_title; ?>"></td></tr>
		</table>
		<input type="hidden" name="option" value="<?php echo $option; ?>" />
		<input type="hidden" name="mp3_id" value="<? echo $row->mp3_id; ?>" />
		<input type="hidden" name="task" value="" />
		</form>
		<?
	}
	
	function listClips($option, &$rows, &$pageNav)
	{
	?>
	<form action="index2.php" method="post" name="adminForm">
	<table cellpadding="4" cellspacing="0" border="0" width="100%" class="adminlist">
	<tr>
	<th width="5"><input type="checkbox" name="toggle" value="" onClick="checkAll(<?php echo count( $rows ); ?>);" /></th>
	<th class="title">Title</th>
	<th class="title">Filename</th>
	<th colspan="2">Reorder</th>
	</tr>	
	<?php
	$k = 0;
	for($i=0; $i < count( $rows ); $i++) {
	$row = $rows[$i];
   ?>
	<tr class="<?php echo "row$k"; ?>">
	<td><input type="checkbox" id="cb<?php echo $i;?>" name="cid[]" value="<?php echo $row->mp3_id; ?>" onclick="isChecked(this.checked);" /></td>
	<td><a href="#edit" onclick="return listItemTask('cb<?php echo $i;?>','edit')"><?php echo $row->mp3_title; ?></a></td>
	<td><? echo $row->mp3_filename ?></td>
	<td align="right">
	<?php echo $pageNav->orderUpIcon( $i, ($row->dummy == @$rows[$i-1]->dummy) ); ?>
	</td>
	<td align="left">
	<?php echo $pageNav->orderDownIcon( $i, $n, ($row->dummy == @$rows[$i+1]->dummy) ); ?>
	</td>
	<?php $k = 1 - $k; ?>
	</tr>
<?php } 

?>
	</table>
	<input type="hidden" name="boxchecked" value="0" />
	<input type="hidden" name="option" value="<?php echo $option; ?>" />
	<input type="hidden" name="task" value="" />
	</form> 

	<?	
	}
}

?>