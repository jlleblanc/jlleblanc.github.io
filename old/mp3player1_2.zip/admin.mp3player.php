<?
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

require_once( $mainframe->getPath( 'admin_html' ) );
require_once( $mainframe->getPath( 'class' ) );

$cid = mosGetParam($_REQUEST, 'cid', array());

switch ( $act )
{
	case "info":
	showInformation($option);
	break;
	
	case "settings":
	switch($task)
	{
		case "save":
		saveSettings($option);
		break;
		
		default:
		editSettings($option);
		break;
	}
	break;
	
	default:	
	switch($task)
	{
		case "orderup":
		orderClip( $cid[0], -1, $option );
		break;

		case "orderdown":
		orderClip( $cid[0], 1, $option );
		break;
		
		case "delete":
		deleteClips($option, $cid);
		break;

		case "save":
		saveClip($option);		
		break;
		
		case "new":
		editClip($option, 0);
		break;
		
		case "edit":
		editClip($option, $cid[0]);
		break;
		
		default:
		listClips($option);
		break;
	}
	break;
}

function showInformation($option)
{
	mp3Player_HTML::showInformation($option);
}

function saveSettings($option)
{
		global $database;

        $params = mosGetParam( $_REQUEST, 'params', '' );
        if (is_array( $params )) {
            $txt = array();
            foreach ($params as $k=>$v) {
                $txt[] = "$k=$v";
                }
                $_REQUEST['params'] = mosParameters::textareaHandling( $txt );
        }

        $row = new mosComponent( $database );
        $database->setQuery("SELECT * FROM #__components WHERE link = 'option=com_podcast'");
        $database->loadObject($row);

        if (!$row->bind( $_REQUEST )) {
                echo "<script> alert('".$row->getError()."'); window.history.go(-1); </script>\n";
                exit();
        }

        if (!$row->check()) {
                echo "<script> alert('".$row->getError()."'); window.history.go(-1); </script>\n";
                exit();
        }
        if (!$row->store()) {
                echo "<script> alert('".$row->getError()."'); window.history.go(-1); </script>\n";
                exit();
        }

        $msg = 'Settings successfully Saved';
        mosRedirect( 'index2.php?option='. $option, $msg);
	
}

function editSettings($option)
{
		global $database, $mainframe;
		
	    $query = "SELECT a.id"
        . "\n FROM #__components AS a"
        . "\n WHERE a.option = '$option'"
        ;
        $database->setQuery( $query );
        $compid = $database->loadResult();

        // load the row from the db table
        $row = new mosComponent( $database );
        $row->load( $compid );

        // get params definitions
        $params =& new mosParameters( $row->params, $mainframe->getPath( 'com_xml', $row->option ), 'component' );
	
		mp3Player_HTML::editSettings($option, $params, $compid);
}

function deleteClips($option, $cid)
{
	global $database;
	
	$clips = join(",", $cid);
	
	$database->SetQuery("DELETE FROM #__mp3player WHERE mp3_id IN ($clips)");
	$database->Query();
	
	$s = "";	
	if(count($cid) > 1) $s = "s";
	
	mosRedirect("index2.php?option=$option", "Playlist item$s deleted.");
}

function saveClip($option)
{
	global $database;
	$row = new mp3Player($database);
	
	// bind it to the table
	if (!$row -> bind($_POST)) {
		echo "<script> alert('"
			.$row -> getError()
			."'); window.history.go(-1); </script>\n";
		exit();
	}

	// store it in the db
	if (!$row -> store()) {
		echo "<script> alert('"
			.$row -> getError()
			."'); window.history.go(-1); </script>\n";
		exit();	
	}
	
	$row->updateOrder();
		
	mosRedirect("index2.php?option=$option", "Playlist item saved.");
}

function editClip($option, $id)
{
	global $database;
	
	$row = null;
	
	$database->SetQuery("SELECT * FROM #__mp3player WHERE mp3_id = '$id'");
	$database->loadObject($row);
	
	mp3Player_HTML::editClip($option, $row);
}

function orderClip( $id, $inc, $option ) {
	global $database;

	$row = new mp3Player( $database );
	$row->load( $id );
	$row->move( $inc, "" );

	mosRedirect( 'index2.php?option='. $option);
}


function listClips($option)
{
	global $database, $mainframe, $mosConfig_absolute_path;
	require_once( $mosConfig_absolute_path . '/administrator/includes/pageNavigation.php' );
	

	$limit 				= $mainframe->getUserStateFromRequest( "viewlistlimit", 'limit', $mosConfig_list_limit );
	$limitstart 		= $mainframe->getUserStateFromRequest( "view{$option}{$sectionid}limitstart", 'limitstart', 0 );
	
	$database->SetQuery("SELECT * FROM #__mp3player ORDER BY ordering");
	$rows = $database->loadObjectList();
		
	$pageNav = new mosPageNav( count($rows), $limitstart, $limit );
		
	mp3Player_HTML::listClips($option, $rows, $pageNav);
}

?>