<?
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

class mp3Player extends mosDBTable {
	var $mp3_id = null;
	var $mp3_filename = null;
	var $mp3_title = null;
	var $ordering = null;
	var $dummy = 1;
	
	function mp3Player(&$db){
		$this->mosDBTable('#__mp3player', 'mp3_id', $db);
	}
}

?>