DROP TABLE `#__giveaway_attendee`;
DROP TABLE `#__giveaway_swag`;
