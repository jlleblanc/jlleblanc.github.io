<?php
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view');

class PodcastViewInfo extends JView {
	public function display()
	{
		parent::display();
	}
}