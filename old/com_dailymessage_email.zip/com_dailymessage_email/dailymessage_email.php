<?
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

require_once ( $mainframe->getPath( 'front_html' ) );

$id = mosGetParam($_REQUEST, 'id', '');

switch( $task )
{
	case "sendemail":
	SendEmail($option, $id);
	break;

	case "emailform":
	EmailForm($option, $id);
	break;

	default:
	ListMessages($option);
	break;
}

function SendEmail($option, $id)
{

	global $database;

	$sendername = mosGetParam($_REQUEST, 'sendername', '');
	$emailfrom = mosGetParam($_REQUEST, 'emailfrom', '');
	$emailto = mosGetParam($_REQUEST, 'emailto', '');
	$note = mosGetParam($_REQUEST, 'note', '');

	if(!$sendername || !$emailfrom || !$emailto)
	{
		dailymessage_HTML::FillAllFields();
		EmailForm($option, $id);
		return;
	}

	$subject = "A message you may find interesting";

	if($note)
	{
		$message = $note . "\n\n";
	} else {
		$message = "$sendername thought you might find this message interesting.\n\n";
	}

	$database->SetQuery("SELECT * FROM #__email_dailymessage WHERE id = '" . $id . "'");
	$rows = $database->loadObjectList();
	$row = $rows[0];

	$message .= $row->message . " " . mosFormatDate($row->date);

	mosMail($emailfrom, $sendername, $emailto, $subject, $message);

	dailymessage_HTML::Success();
}

function EmailForm($option, $id)
{
        $sendername = mosGetParam($_REQUEST, 'sendername', '');
        $emailfrom = mosGetParam($_REQUEST, 'emailfrom', '');
        $emailto = mosGetParam($_REQUEST, 'emailto', '');
        $note = mosGetParam($_REQUEST, 'note', '');

	dailymessage_HTML::EmailForm($option, $id, $sendername, $emailfrom, $emailto, $note);
}


function ListMessages ($option)
{

global $database;

// get configuration information
$database->setQuery("SELECT * FROM #__email_dailymessage_conf LIMIT 1");

$rows = $database->loadObjectList();
$row = $rows[0];

$bold = $row->bold;
$italic = $row->italic;
$underline = $row->underline;
$showdate = $row->showdate;

$starttags = "";
$endtags = "";

if($bold == 1)
{
        $starttags .= "<b>";
        $endtags = "</b>" . $endtags;
}

if($italic == 1)
{
        $starttags .= "<i>";
        $endtags = "</i>" . $endtags;
}

if($underline == 1)
{
        $starttags .= "<u>";
        $endtags = "</u>" . $endtags;
}

//get data and output accordingly

$database->setQuery("SELECT * FROM #__email_dailymessage WHERE published = '1'");

$rows = $database->loadObjectList();


dailymessage_HTML::ListMessages ($option, $bold, $italic, $underline, $showdate, $starttags, $endtags, $rows);

}

?>
