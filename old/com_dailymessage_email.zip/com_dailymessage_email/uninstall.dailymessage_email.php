<?
function com_uninstall() {
}
?> 
