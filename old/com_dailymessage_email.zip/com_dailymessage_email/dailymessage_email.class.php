<?

defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

class joeDailyMessage extends mosDBTable {
	var $id = null;
	var $message = null;
	var $date = null;
	var $published = null;
	
	function joeDailyMessage(&$db){
		$this->mosDBTable('#__email_dailymessage', 'id', $db);
	}
}

class joeDailyMessageConf extends mosDBTable {
	var $bold = null;
	var $italic = null;
	var $underline = null;
	var $showdate = null;
	var $configid = null;
	
	function joeDailyMessageConf(&$db){
		$this->mosDBTable('#__email_dailymessage_conf', 'configid', $db);
	}
}

?>