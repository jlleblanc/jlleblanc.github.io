<?php
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

class menuDailyMessage{
	function DEFAULT_MENU() {
		mosMenuBar::startTable();
		mosMenuBar::publish('publish');
		mosMenuBar::unpublish('unpublish');
		mosMenuBar::divider();
		mosMenuBar::addNew('new');
		mosMenuBar::editList('edit', 'Edit');
		mosMenuBar::deleteList( ' ', 'delete', 'Remove' );
		mosMenuBar::endTable();
		}
	function EDIT_MENU() {
		mosMenuBar::startTable();
		mosMenuBar::back();
		mosMenuBar::spacer();
		mosMenuBar::save('save');
		mosMenuBar::endTable();
	}
	function CONFIGURE_MENU() {
		mosMenuBar::startTable();
		mosMenuBar::save('save');
		mosMenuBar::endTable();
	}
}

?>