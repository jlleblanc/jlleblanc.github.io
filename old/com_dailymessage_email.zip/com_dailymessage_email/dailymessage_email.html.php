<?

defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );


class dailymessage_HTML {

function FillAllFields()
{
	?><center><font color="#FF0000">Please fill in all of the fields.</font></center><?
}

function Success()
{
	?>
        <center><b>Message sent successfully.</b><BR><BR>
        <input type="button" value="Close" class="button" onClick="{window.close();}">
        </center>
	<?

}

function EmailForm($option, $id, $sendername, $emailfrom, $emailto, $note)
{

        ?>
        <form action="index2.php" method="post">
        <table>
        <tr><td colspan="2" align="center">Send this message</td></tr>
        <tr><td align="left">Your Name:</td> <td><input name="sendername" value="<? echo $sendername; ?>"></td></tr>
        <tr><td align="left">Your e-mail:</td> <td><input name="emailfrom" value="<? echo $emailfrom; ?>"></td></tr>
        <tr><td align="left">Your friend's e-mail:</td> <td><input name="emailto" value="<? echo $emailto; 
?>"></td></tr>
        <tr><td align="left">An additional note (optional):</td> <td><textarea name="note" rows="5" cols="30">
<? echo $note; ?></textarea></td></tr>
        <tr><td colspan="2" align="center"><input type="submit" value="Send Message" class="button">&nbsp;
<input type="button" value="Cancel" class="button" onClick="{window.close();}"></td></tr>
        </table>

        <input type="hidden" name="id" value="<? echo $id; ?>">
        <input type="hidden" name="task" value="sendemail">
        <input type="hidden" name="option" value="<? echo $option; ?>">
        </form>
        <?
} // EmailForm()


function ListMessages($option, $bold, $italic, $underline, $showdate, $starttags, $endtags, &$rows)
{

?><table><?


foreach($rows as $row)
{
        $button = "<a href=\"#\" onClick=\"javascript:{ window.open('index2.php?option=$option&task=emailform&id=" . $row->id . "', 'emailform', 'height=350,width=400'); }\"><img src=\"images/M_images/emailButton.png\" border=\"0\"></a>";
        if($showdate == 1)
                echo "<tr><td>" . mosFormatDate($row->date) . "</td>";
        else
                echo "<tr>";

        echo "<td>" . $starttags . $row->message . $endtags . "&nbsp;" . $button . "</td></tr>";
}

?></table><?

} 

} // class dailymessage_HTML

?>
