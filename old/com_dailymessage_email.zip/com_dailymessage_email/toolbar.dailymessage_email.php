<?
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );
require_once( $mainframe->getPath( 'toolbar_html' ) ); 


switch ( $task ) {
		case 'edit':
		menuDailyMessage::EDIT_MENU();
		break;

		case 'new':
		menuDailyMessage::EDIT_MENU();
		break;

		default:
		switch($act)
		{
			case "configure":
			menuDailyMessage::CONFIGURE_MENU();
			break;

			default:
			menuDailyMessage::DEFAULT_MENU();
			break;		
		}
		break;
	}
?>
