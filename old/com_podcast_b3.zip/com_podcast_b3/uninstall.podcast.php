<?
function com_uninstall() {
}
?> 
