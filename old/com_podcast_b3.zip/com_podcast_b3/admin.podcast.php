<?

// Podcast component, based on the syndicate component from Mambo core
// Portions copyright (C) 2000 - 2005 Miro International Pty Ltd
// GNU/GPL licence

defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

global $mosConfig_absolute_path, $database;

$cid = mosGetParam($_REQUEST, 'cid', array(''));
$file = $cid[0];

require_once( $mainframe->getPath( 'admin_html' ) );
require_once( $mainframe->getPath( 'class' ) );

        $query = "SELECT a.id"
        . "\n FROM #__components AS a"
        . "\n WHERE a.option = '$option'"
        ;
        $database->setQuery( $query );
        $compid = $database->loadResult();

        // load the row from the db table
        $row = new mosComponent( $database );
        $row->load( $compid );

        // get params definitions
        $params =& new mosParameters( $row->params, $mainframe->getPath( 'com_xml', $row->option ), 'component' );

// check to see if podcast Mambot is installed and published.
$mambot = null;
$database->SetQuery("SELECT * FROM #__mambots WHERE element = 'podcast'");
$database->loadObject($mambot);

HTML_podcast::podcastWarning($option, $mambot, $params);

switch( $act )
{
	case "publishmambot":
	publishMambot($option);
	break;
	
	case "clips":
	switch ( $task )
	{
		case "upload":
		break;

		case "save":
		saveClip($option, $params);
		break;

		case "new":
		editClip($option, "", $params);
		break;

		case "edit":
		case "publish":
		editClip($option, $file, $params);
		break;

		case "help":
		mosRedirect("index2.php?option=$option&act=info");
		break;

		default:
		listClips($option, $params);
		break;
	}
	break;

	case "settings":
	switch( $task )
	{
		case "save":
		SaveSettings( $option, $params);
		break;

		case "cancel":
		mosRedirect("index2.php?option=$option");
		break;

		default:
		ShowSettings($option, $params, $compid);
		break;

	}
	break;

	case "info":
	{
		include($mosConfig_absolute_path . "/administrator/components/com_podcast/" . "info.podcast.php");
	}
	break;

	default:
	switch ( $task )
	{
		default:
		listClips($option, $params);
		break;
	}
	break;
}

function saveClip($option, &$params)
{
	global $database;
	

	$row = new mosContent($database);
	
	// bind it to the table
	if (!$row -> bind($_POST)) {
		echo "<script> alert('"
			.$row -> getError()
			."'); window.history.go(-1); </script>\n";
		exit();
	}
	
	$row->sectionid = $params->get('section', 0);
	if(!$row->id)
	{
		$row->created = date("Y-m-d H:m:s");
	}

	// store it in the db
	if (!$row -> store()) {
		echo "<script> alert('"
			.$row -> getError()
			."'); window.history.go(-1); </script>\n";
		exit();	
	}
	
	$content_id = $row->id; // save content_id
	
	$row = new Podcast($database);

	// bind it to the table
	if (!$row -> bind($_POST)) {
		echo "<script> alert('"
			.$row -> getError()
			."'); window.history.go(-1); </script>\n";
		exit();
	}	

	$row->article_id = $content_id;
	
	// store it in the db
	if (!$row -> store()) {
		echo "<script> alert('"
			.$row -> getError()
			."'); window.history.go(-1); </script>\n";
		exit();	
	}

	mosRedirect("index2.php?option=$option", "Clip information saved.");
}

function editClip($option, $file, &$params)
{
	global $database, $task;
	
	$database->SetQuery("SELECT * FROM #__content AS c LEFT JOIN #__podcast AS p ON p.article_id = c.id\n"
						." WHERE c.introtext LIKE '%{enclose ". $file ."}%' AND c.state >= 0\n"
						." ORDER BY c.state DESC");
	$database->loadObject($row);
	
	if(!ereg("{enclose " . $file . "}", $row->introtext))
	{
		$row->introtext .= "<BR>{enclose " . $file . "}";
	}
	
	$database->SetQuery("SELECT * FROM #__categories WHERE section = '" . $params->get('section', 0) . "' AND published = '1'");
	$cats = $database->loadObjectList();
	
	$categories = "<select name=\"catid\">\n";
	$categories .= "<option value=\"0\">(select...)</option>";
	foreach($cats as $cat)
	{
		$categories .= "<option value=\"" . $cat->id . "\"";
		if($cat->id == $row->catid) $categories .= " selected";  
		$categories .= ">" . $cat->title . "</option>\n";
	}
	$categories .= "</select>";
	
	HTML_podcast::editClip($option, $row, $task, $categories, $file, $params);
}

function publishMambot($option)
{
	global $database;
	
	$database->SetQuery("UPDATE #__mambots SET published = '1' WHERE element = 'podcast'");
	$database->Query();
	
	mosRedirect("index2.php?option=" . $option, "Podcast mambot published.");
}

function listClips($option, &$params)
{
	global $mosConfig_absolute_path, $mosConfig_list_limit, $database, $mainframe;

	$limit 	= $mainframe->getUserStateFromRequest( "viewlistlimit", 'limit', $mosConfig_list_limit );
	$limitstart = $mainframe->getUserStateFromRequest( "view{$option}limitstart", 'limitstart', 0 );

	$mediapath = $params->def( 'mediapath', 'images/stories' );

	$clipdir = opendir($mosConfig_absolute_path . '/' . $mediapath);
	
	$files = array();
	$filename = "";
	while (false !== ($filename = readdir($clipdir))) {
		if($filename == ".." || $filename == ".") continue;
		if(is_dir($mosConfig_absolute_path . '/' . $mediapath . '/' . $filename)) continue;
		$files[] = $filename;
	}

/*	$allcontent = "";
	$database->SetQuery("SELECT * FROM #__content");
	$rows = $database->loadObjectList();
	if(count($rows))
	{
		foreach($rows as $row)
		{
			$allcontent .= $row->introtext;
			$allcontent .= $row->fulltext;
		}
	} */

	require_once( $mosConfig_absolute_path . '/administrator/includes/pageNavigation.php' );
	$pageNav = new mosPageNav( count($files), $limitstart, $limit  );

	$files = array_slice($files, $pageNav->limitstart, $pageNav->limit);	

	HTML_podcast::listClips($option, $files, /* $allcontent, */ $pageNav, $params);
}

function ShowSettings( $option, &$params, $id ) {
        global $database, $mainframe, $mosConfig_list_limit;

        HTML_podcast::settings( $option, $params, $id );
}

function SaveSettings( $option ) {
        global $database;

        $params = mosGetParam( $_REQUEST, 'params', '' );
        if (is_array( $params )) {
            $txt = array();
            foreach ($params as $k=>$v) {
                $txt[] = "$k=$v";
                }
                $_REQUEST['params'] = mosParameters::textareaHandling( $txt );
        }

        $row = new mosComponent( $database );
//      $database->setQuery("SELECT * FROM #__components WHERE link = 'option=com_podcast'");
//      $database->loadObject($row);

        if (!$row->bind( $_REQUEST )) {
                echo "<script> alert('".$row->getError()."'); window.history.go(-1); </script>\n";
                exit();
        }

        if (!$row->check()) {
                echo "<script> alert('".$row->getError()."'); window.history.go(-1); </script>\n";
                exit();
        }
        if (!$row->store()) {
                echo "<script> alert('".$row->getError()."'); window.history.go(-1); </script>\n";
                exit();
        }

        $msg = 'Settings successfully Saved';
        mosRedirect( 'index2.php?option='. $option, $msg);
}


?>
