<?php
/**
* @version $Id: mod_rssfeed.php,v 1.4 2005/01/06 01:13:32 eddieajau Exp $
* @pacakge Mambo
* @copyright (C) 2000 - 2005 Miro International Pty Ltd
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* Mambo is Free Software
*/

/** ensure this file is being included by a parent file */
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

global $mosConfig_live_site, $mosConfig_absolute_path, $cur_template;

$text 			= $params->get( 'text' );
$moduleclass_sfx 	= $params->get( 'moduleclass_sfx', '' );
$rss20  			= $params->get( 'rss20', 1 );
$opml  			= $params->get( 'opml', 1 );
$rss20_image		= $params->get( 'rss20_image', 'podcast-mini2.gif' );
$opml_image		= $params->get( 'opml_image', '' );

$t_path 			= $mosConfig_live_site .'/templates/'. $cur_template .'/images/';
$d_path			= $mosConfig_live_site .'/images/M_images/';

?>

<div class="syndicate<?php echo $moduleclass_sfx;?>">

<?php
// rss20 link
if ( $rss20 ) {
	$img = mosAdminMenus::ImageCheck( 'podcast-mini2.gif', '/modules/', $rss20_image, '/modules/', 'Podcast' );
	?>
	<div align="center">
	<? echo $text; ?>
	<a href="<?php echo $mosConfig_live_site ?>/index2.php?option=com_podcast&amp;feed=RSS2.0&amp;no_html=1">
	<?php echo $img ?>
	</a>
	</div>
	<?php
}
?>

<?php
// opml link
// under development, contact@jlleblanc.com
if ( $opml == 50000) {
	$img = mosAdminMenus::ImageCheck( 'opml.png', '/images/M_images/', $opml_image, '/images/M_images/', 'OPML' );
	?>
	<div align="center">
	<a href="<?php echo $mosConfig_live_site ?>/index2.php?option=com_podcast&amp;feed=OPML&amp;no_html=1">
	<?php echo $img ?>
	</a>
	</div>
	<?php
}
?>
</div>