<?php
defined( '_JEXEC' ) or die( 'Restricted access' );

switch ($task) {
	case 'demo1':
		demo1();
		break;
	
	case 'demo2':
		demo2();
		break;
	
	case 'demo3':
		demo3();
		break;
	
	case 'demo4':
		demo4();
		break;
		
	case 'demo5':
		demo5();
		break;
	
	default:
		showDemos($option);
		break;
}

function demo1()
{
	$user =& JFactory::getUser();
	
	echo "<p>Your name is {$user->name}, your email is {$user->email}, and your username is {$user->username}</p>";
	echo "<p>Your usertype is {$user->usertype} which has a group id of {$user->gid}.</p>";
	
}

function demo2()
{
	$user =& JFactory::getUser();
	$language = $user->getParam('language', 'the default');
	
	echo "<p>Your language is set to {$language}.</p>";
}

function demo3()
{
	$user =& JFactory::getUser();
	
	if ($user->guest) {
		echo "<p>You must login to see the content. I want your email address.</p>";
	} else {
		?>
		
		<h1>Impromptu leftovers salad that goes well with fish</h1>
		<ul>
			<li>1/2 cup chopped celery</li>
			<li>1/4 cup raisins</li>
			<li>1 teaspoon Extra Virgin Olive Oil</li>
			<li>2 tablespoons of faux Thai lemongrass marinade</li>
			<li>1/4 cup shredded fresh basil</li>
			<li>Sprinkling of dill weed</li>
			<li>Big pinch of kosher salt</li>
			<li>Several lettuce leaves (to taste)</li>
		</ul>
		
		<p>Wash the lettuce and basil because there's no telling who touched it before you did, even if the package says "prewashed." Put them in a bowl; preferably a hand-crafted salad bowl, but a metallic measuring bowl will also do. Get out a much smaller bowl and swish around all of the remaining ingredients. Actually, if you don't want to dirty up a perfectly good and clean bowl, you can probably just use the first bowl for this step and dump the greens on top. Toss irregularly. Consume promptly. Serves two, unless somebody eats a smaller portion.</p>

		<?php
	}
}

function demo4()
{
	// libraries/joomla/user/authorization.php
	
	$user =& JFactory::getUser();
	
	if ($user->authorize('com_content', 'edit', 'content', 'all')) {
		echo "<p>You may edit all content.</p>";
	} else {
		echo "<p>You may not edit all content.</p>";
	}
	
	if ($user->authorize('com_content', 'publish', 'content', 'own')) {
		echo "<p>You may publish your own content.</p>";
	} else {
		echo "<p>You may not publish your own content.</p>";
	}
	
}

function demo5()
{	
	$auth =& JFactory::getACL();
	
	$auth->addACL('com_userinfo15', 'persuade', 'users', 'super administrator');
	$auth->addACL('com_userinfo15', 'persuade', 'users', 'administrator');
	$auth->addACL('com_userinfo15', 'persuade', 'users', 'manager');

	$user =& JFactory::getUser();
	
	if ($user->authorize('com_userinfo15', 'persuade')) {
		echo "<p>You may persuade the system to do what you wish.</p>";
	} else {
		echo "<p>You are not very persuasive.</p>";
	}
	
}

function showDemos($option)
{
	?>
	<ul>
	<li><a href="<?php echo JRoute::_('index.php?option=' . $option . '&task=demo1') ?>">User Demo 1</a></li>
	<li><a href="<?php echo JRoute::_('index.php?option=' . $option . '&task=demo2') ?>">User Demo 2</a></li>
	<li><a href="<?php echo JRoute::_('index.php?option=' . $option . '&task=demo3') ?>">User Demo 3</a></li>
	<li><a href="<?php echo JRoute::_('index.php?option=' . $option . '&task=demo4') ?>">User Demo 4</a></li>
	<li><a href="<?php echo JRoute::_('index.php?option=' . $option . '&task=demo5') ?>">User Demo 5</a></li>
	</ul>
	<?php
}


?>