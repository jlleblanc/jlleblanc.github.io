<?php
/**
*Copyright 2005, Joseph LeBlanc
*Released under GPL
*/

/** ensure this file is being included by a parent file */
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

global $mosConfig_live_site;

$shortmessage = $params->get( 'shortmessage' );
$button = $params->get( 'button' );
$moduleclass_sfx = $params->get( 'moduleclass_sfx', '' );
$feed = $params->get( 'feed', 'RSS 0.91' );


$feedurl = "";

switch( $feed )
{
	case "RSS 0.91":
	$feedurl = $mosConfig_live_site . '/index2.php?option=com_rss&amp;feed=RSS0.91&amp;no_html=1';
	break;

	case "RSS 1.0":
	$feedurl = $mosConfig_live_site . '/index2.php?option=com_rss&amp;feed=RSS1.0&amp;no_html=1';
	break;

	case "RSS 2.0":
	$feedurl = $mosConfig_live_site . '/index2.php?option=com_rss&amp;feed=RSS2.0&amp;no_html=1';
	break;

	case "Atom":
	$feedurl = $mosConfig_live_site . '/index2.php?option=com_rss&amp;feed=ATOM0.3&amp;no_html=1';
	break;

	default:
	$feedurl = $mosConfig_live_site . '/index2.php?option=com_rss&amp;feed=RSS0.91&amp;no_html=1';
	break;
}

$buttoncode = "";

switch( $button )
{
	case "short":
	$buttoncode = '<img src="http://us.i1.yimg.com/us.yimg.com/i/us/my/addtomyyahoo6.gif" width="89" height="33" border="0">';
	break;

	case "long":
	$buttoncode = '<img src="http://us.i1.yimg.com/us.yimg.com/i/us/my/addtomyyahoo4.gif" width="91" height="17" border="0">';
	break;

	default:
	$buttoncode = '<img src="http://us.i1.yimg.com/us.yimg.com/i/us/my/addtomyyahoo4.gif" width="91" height="17" border="0">';
	break;
}

?>

<div class="myyahoo<?php echo $moduleclass_sfx;?>">

<?php

if($shortmessage)
{
	echo '<div align="center" class="myyahoo_text'  . $moduleclass_sfx . '">' . $shortmessage . '</div>';
}

?>
	<div align="center">
	<a href="<?php echo 'http://add.my.yahoo.com/rss?url=' . $feedurl; ?>">
	<?php echo $buttoncode ?>
	</a>
	</div>

</div>