<?php

defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

$_MAMBOTS->registerFunction( 'onPrepareContent', 'botPodcast' );

function botPodcast( $published, &$row, &$params, $page=0 ) {


	global $database, $mosConfig_live_site;

	$query = "SELECT a.id"
	. "\n FROM #__components AS a"
	. "\n WHERE a.option = 'com_podcast'"
	;
	$database->setQuery( $query );
	$id = $database->loadResult();

	// load syndication parameters
	$component = new mosComponent( $database );
	$component->load( $id );
	$pParams =& new mosParameters( $component->params );


	$regex = "#{enclose (.*?)}#s";
	preg_match_all($regex, $row->text, $parameters);

        foreach($parameters[1] as $par)
        {
                // get details from parameters
                $paramarray = explode(" ", $par);

		// detect if this is an external link

		if(!eregi('http://', $paramarray[0]) && !eregi('https://', $paramarray[0]))
		{
			$paramarray[0] = $pParams->def( 'mediapath', 'images/stories' ) . "/" . $paramarray[0];
		}

		$linkhandling = $pParams->def( 'linkhandling', 'links');
		$linktitle = $pParams->def( 'linktitle', 'Listen Now!');
		$linkcode = $pParams->def( 'linkcode', '');

		if($linkhandling == 'links')
		{
			$link = '<a href="' . $mosConfig_live_site . "/" . $paramarray[0] . '">' . $linktitle . '</a>';
		}
		else if($linkhandling == 'html')
		{
			$link = preg_replace('/\{filename\}/', $paramarray[0], $linkcode);
		}

		// replace link
		$row->text = preg_replace( "#{enclose ". $par ."}#s", $link, $row->text );
        }
	
	return true;
}
?>
