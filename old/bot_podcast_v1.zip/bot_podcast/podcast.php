<?php

defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

$_MAMBOTS->registerFunction( 'onPrepareContent', 'botPodcast' );

function botPodcast( $published, &$row, &$params, $page=0 ) {


	global $database, $mosConfig_live_site;

	$query = "SELECT a.id"
	. "\n FROM #__components AS a"
	. "\n WHERE a.option = 'com_podcast'"
	;
	$database->setQuery( $query );
	$id = $database->loadResult();

	// load syndication parameters
	$component = new mosComponent( $database );
	$component->load( $id );
	$pParams =& new mosParameters( $component->params );


	$regex = "#{enclose (.*?)}#s";
	preg_match_all($regex, $row->text, $parameters);

        foreach($parameters[1] as $par)
        {
                // get details from parameters
                $paramarray = explode(" ", $par);

		// if not an external link, add the current path

		if(!eregi('http://', $paramarray[0]) && !eregi('https://', $paramarray[0]))
		{
			$paramarray[0] = $pParams->def( 'mediapath', 'images/stories' ) . "/" . $paramarray[0];
		}

		$linkhandling = $pParams->def( 'linkhandling', 'links');
		$linktitle = $pParams->def( 'linktitle', 'Listen Now!');
		$linkcode = $pParams->def( 'linkcode', '');

		if($linkhandling == 'links')
		{
			$link = '<a href="' . $mosConfig_live_site . "/" . $paramarray[0] . '">' . $linktitle . '</a>';
		}
		else if($linkhandling == 'html')
		{
			$link = preg_replace('/\{filename\}/', $paramarray[0], $linkcode);
		}
		else if($linkhandling == 'player')
		{
			$link = '<embed wmode="transparent" src="' . $mosConfig_live_site . '/components/com_podcast/music.swf?url=' . $paramarray[0] . '&mode=play&autostart=false" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="150" height="50"></embed>';
		}

		// replace link
		$row->text = preg_replace( "#{enclose ". $par ."}#s", $link, $row->text );
        }


	// Note: this code is exactly the same as above, except that I'm using {player ... } instead of {enclose ... }.
	// I'll probably turn this into a function later on to cut down on code duplication
	$regex = "#{player (.*?)}#s";
	preg_match_all($regex, $row->text, $parameters);

        foreach($parameters[1] as $par)
        {
                // get details from parameters
                $paramarray = explode(" ", $par);

		// detect if this is an external link

		if(!eregi('http://', $paramarray[0]) && !eregi('https://', $paramarray[0]))
		{
			$paramarray[0] = $pParams->def( 'mediapath', 'images/stories' ) . "/" . $paramarray[0];
		}

		$linkhandling = $pParams->def( 'linkhandling', 'links');
		$linktitle = $pParams->def( 'linktitle', 'Listen Now!');
		$linkcode = $pParams->def( 'linkcode', '');

		if($linkhandling == 'links')
		{
			$link = '<a href="' . $mosConfig_live_site . "/" . $paramarray[0] . '">' . $linktitle . '</a>';
		}
		else if($linkhandling == 'html')
		{
			$link = preg_replace('/\{filename\}/', $paramarray[0], $linkcode);
		}
		else if($linkhandling == 'player')
		{
			$link = '<embed wmode="transparent" src="' . $mosConfig_live_site . '/components/com_podcast/music.swf?url=' . $paramarray[0] . '&mode=play&autostart=false" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="150" height="50"></embed>';
		}


		// replace link
		$row->text = preg_replace( "#{player ". $par ."}#s", $link, $row->text );
        }
	
	return true;
}
?>
