<?php 
defined('_VALID_MOS') or die('Direct Access to this location is not allowed.');

// ensure user has access to this function
if (!($acl->acl_check( 'administration', 'edit', 'users', $my->usertype, 'components', 'all' )
		| $acl->acl_check( 'administration', 'edit', 'users', $my->usertype, 'components', 'com_dailymessage_htmldate' ))) {
	mosRedirect( 'index2.php', _NOT_AUTH );
}

require_once( $mainframe->getPath( 'admin_html' ) );
require_once( $mainframe->getPath( 'class' ) );

$id = mosGetParam( $_REQUEST, 'cid', array(0) );
if (!is_array( $id )) {
	$id = array(0);
}


switch($act)
{
	case "configure":
	switch($task) {
		case "save":
		saveConfiguration($option);
		break;

		default:
		listConfiguration($option);
		break;
	}
	break;

	default:
	switch ($task) {
		case "save" :
			save($option);
			break;

		case "edit" :
			edit( $option, $id );
			break;

		case "new" :
			$id = '';
			edit( $option, $id);
			break;
	
		case "delete" :
			del($option, $id);
			break;

		case "publish" :
			publishMessage($option, '1', $id);
			break;

		case "unpublish" :
			publishMessage($option, '0', $id);
			break;

		case "listMessages" :
			default:
			listMessages($option);
			break;

	}
	break;
}


function saveConfiguration($option) {
	global $database;
	$row = new joeDailyMessageConf($database);

	
	// bind it to the table
	if (!$row -> bind($_POST)) {
		echo "<script> alert('"
			.$row -> getError()
			."'); window.history.go(-1); </script>\n";
		exit();
	}


	// store it in the db
	if (!$row -> store()) {
		echo "<script> alert('"
			.$row -> getError()
			."'); window.history.go(-1); </script>\n";
		exit();	
	}

	mosRedirect("index2.php?option=$option&act=configure", "Configuration Saved");
}


function listConfiguration($option)
{
	global $database;

	$database->setQuery("SELECT * FROM #__joe_dailymessage_htmldate_conf"  );
	$rows = $database -> loadObjectList();
	if ($database -> getErrorNum()) {
		echo $database -> stderr();
		return false;
	}
	HTML_joeDailyMessage::listConfiguration($option, $rows);
}



function publishMessage( $option, $publish=1 ,$cid )
{
	global $database, $my;

	if (!is_array( $cid ) || count( $cid ) < 1) {
		$action = $publish ? 'publish' : 'unpublish';
		echo "<script> alert('Select an item to $action'); window.history.go(-1);</script>\n";
		exit;
	}

	$cids = implode( ',', $cid );

	$database->setQuery( "UPDATE #__joe_dailymessage_htmldate SET published='$publish'"
	. "\nWHERE id IN ($cids)"
	// AND (checked_out=0 OR (checked_out='$my->id')
	);
	if (!$database->query()) {
		echo "<script> alert('".$database->getErrorMsg()."'); window.history.go(-1); </script>\n";
		exit();
	}

	mosRedirect( "index2.php?option=$option" );

}


function save($option) {
	global $database;
	$row = new joeDailyMessage($database);

	// bind it to the table
	if (!$row -> bind($_POST)) {
		echo "<script> alert('"
			.$row -> getError()
			."'); window.history.go(-1); </script>\n";
		exit();
	}

	// store it in the db
	if (!$row -> store()) {
		echo "<script> alert('"
			.$row -> getError()
			."'); window.history.go(-1); </script>\n";
		exit();	
	}
	mosRedirect("index2.php?option=$option", "Saved");
}

function del($option, $cid) {
	global $database;
	if (!is_array($cid) || count($cid) < 1) {
		echo "<script> alert('Select an item to delete'); window.history.go(-1);</script>\n";
		exit();
	}

	if (count($cid))
	{
		$ids = implode(',', $cid);
		$database->setQuery("DELETE FROM #__joe_dailymessage_htmldate \nWHERE id IN ($ids)");
	}
	if (!$database->query()) {
		echo "<script> alert('"
			.$database -> getErrorMsg()
			."'); window.history.go(-1); </script>\n";
	}
	mosRedirect("index2.php?option=$option");

}

function edit($option, $uid) {
	global $database;

	$row = new joeDailyMessage($database);

	if($uid){
		$row -> load($uid[0]);
	}
		HTML_joeDailyMessage::edit($option, $row);
}

function listMessages($option) {
	global $database;

	$database->setQuery("SELECT * FROM #__joe_dailymessage_htmldate ORDER BY id"  );
	$rows = $database -> loadObjectList();
	if ($database -> getErrorNum()) {
		echo $database -> stderr();
		return false;
	}
	HTML_joeDailyMessage::listMessages($option, $rows);
}


?>