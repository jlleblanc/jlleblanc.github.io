<?

defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

class joeDailyMessage extends mosDBTable {
	var $id = null;
	var $message = null;
	var $date = null;
	var $published = null;
	
	function joeDailyMessage(&$db){
		$this->mosDBTable('#__joe_dailymessage_htmldate', 'id', $db);
	}
}

class joeDailyMessageConf extends mosDBTable {
	var $bold = null;
	var $italic = null;
	var $underline = null;
	var $showdate = null;
	var $configid = null;
	
	function joeDailyMessageConf(&$db){
		$this->mosDBTable('#__joe_dailymessage_htmldate_conf', 'configid', $db);
	}
}

?>