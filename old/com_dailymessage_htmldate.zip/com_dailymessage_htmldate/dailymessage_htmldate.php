<?
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

global $database;

// get configuration information
$database->setQuery("SELECT * FROM #__joe_dailymessage_htmldate_conf LIMIT 1");

$rows = $database->loadObjectList();
$row = $rows[0];

$bold = $row->bold;
$italic = $row->italic;
$underline = $row->underline;
$showdate = $row->showdate;

$starttags = "";
$endtags = "";

if($bold == 1)
{
	$starttags .= "<b>";
	$endtags = "</b>" . $endtags;
}

if($italic == 1)
{
	$starttags .= "<i>";
	$endtags = "</i>" . $endtags;
}

if($underline == 1)
{
	$starttags .= "<u>";
	$endtags = "</u>" . $endtags;
}

//get data and output accordingly

$database->setQuery("SELECT * FROM #__joe_dailymessage_htmldate WHERE published = '1'");

$rows = $database->loadObjectList();

?><table><?

foreach($rows as $row)
{
	if($showdate == 1)
		echo "<tr><td>" . mosFormatDate($row->date) . "</td>";
	else
		echo "<tr>";

	echo "<td>" . $starttags . $row->message . $endtags . "</td></tr>";
}

?></table><?

?>