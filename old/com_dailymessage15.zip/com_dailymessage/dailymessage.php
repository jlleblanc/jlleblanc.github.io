<?php

defined('_JEXEC') or die();

$db =& JFactory::getDBO();

$db->setQuery("SELECT * FROM #__dailymessage WHERE published = 1 ORDER BY date");
$rows = $db->loadObjectList();

list($begin, $end) = getMessageFormat();

echo '<ul>';

foreach ($rows as $row) {
	echo '<li>' . JHTML::date($row->date) . ' ' . $begin . $row->message . $end . '</li>';
}

echo '</ul>';

function getMessageFormat()
{
	$params =& JComponentHelper::getParams('com_dailymessage');
	
	$italic = $params->get('italic', false);
	$bold = $params->get('bold', false);
	$underline = $params->get('underline', false);
	
	$begin = '';
	$end = '';
	
	if ($italic) {
		$begin .= '<i>';
		$end = '</i>' . $end;
	}
	
	if ($bold) {
		$begin .= '<b>';
		$end = '</b>' . $end;
	}
	
	if ($underline) {
		$begin .= '<u>';
		$end = '</u>' . $end;
	}
	
	$format = array($begin, $end);
	
	return $format;
}