CREATE TABLE `#__dailymessage` (
  `id` int(11) NOT NULL auto_increment,
  `message` text NOT NULL,
  `date` datetime NOT NULL,
  `published` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`)
);