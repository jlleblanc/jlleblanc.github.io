<?php

defined('_JEXEC') or die();

class HTML_DailyMessage
{
	function listMessages($option, &$rows)
	{
		HTML_DailyMessage::setAllMessagesToolbar();
		
		?>
		<form action="index.php" method="post" name="adminForm">
			
			<table class="adminlist">
				<thead>
					<tr>
						<th width="20"><input type="checkbox" name="toggle" value=""  onclick="checkAll(<?php echo count( $rows ); ?>);" /></th>
						<th nowrap="nowrap" class="title">Message</th>
						<th nowrap="nowrap">Date</th>
						<th nowrap="nowrap">Published</th>
					</tr>
				</thead>
				<tbody>
					<?php
					
					$k = 0;
					for ($i=0, $n=count( $rows ); $i < $n; $i++) {
						$row = &$rows[$i];
						
						$published = JHTML::_('grid.published', $row, $i );
 						$checked = JHTML::_('grid.id', $i, $row->id );
						
						$link = 'index.php?option=' . $option . '&task=edit&cid[]='. $row->id;
						
						?>
						<tr class="<?php echo "row$k"; ?>">
							<td align="center">
								<?php echo $checked; ?>
							</td>
							<td>
								<a href="<?php echo $link; ?>" title="Edit Message">
									<?php echo $row->message; ?>
								</a>
							</td>
							<td>
								<?php echo JHTML::date($row->date); ?>
							</td>
							<td align="center">
								<?php echo $published; ?>
							</td>
						<?php
						
						$k = 1 - $k;
					}
					
					?>
				</tbody>
			</table>
			
			<input type="hidden" name="option" value="<?php echo $option; ?>" />
			<input type="hidden" name="task" value="" />
			<input type="hidden" name="boxchecked" value="0" />
		</form>
		<?php
	}
	
	function edit($option, &$row)
	{
		HTML_DailyMessage::setMessageToolbar($row->id);
		
		JHTML::_('behavior.calendar');
		
		?>
		<form action="index.php" method="post" name="adminForm">
		
		<div class="col100">
			<fieldset class="adminform">
			<table class="admintable">
				<tbody>
					<tr>
						<td width="20%" class="key">
							<label for="message">Message</label>
						</td>
						<td>
							<input class="inputbox" type="text" name="message" id="message" size="40" value="<?php echo $row->message; ?>" />
						</td>
					</tr>
					<tr>
						<td width="20%" class="key">
							<label for="date">Date</label>
						</td>
						<td>
							<input class="inputbox" type="text" name="date" id="date" size="40" value="<?php echo $row->date; ?>" />
							<input type="reset" class="button" value="..." onclick="return showCalendar('date', 'y-mm-dd');" />
						</td>
					</tr>
					<tr>
						<td width="20%" class="key">
							<label for="published">Published</label>
						</td>
						<td>
							<?php echo JHTML::_('select.booleanlist',  'published', '', $row->published ); ?>
						</td>
					</tr>
				</tbody>
			</table>
			</fieldset>
		</div>
		
		<input type="hidden" name="option" value="<?php echo $option; ?>" />
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="id" value="<?php echo $row->id ?>" />
		</form>
		<?php
	}
	
	function setMessageToolbar($id)
	{
		if ($id) {
			$newEdit = 'Edit';
		} else {
			$newEdit = 'New';
		}
		
		JToolBarHelper::title($newEdit . ' Message', 'generic.png');
		JToolBarHelper::save();
		JToolBarHelper::cancel();
	}
	
	function setAllMessagesToolbar()
	{
		JToolBarHelper::title('Message Manager', 'generic.png');
		JToolBarHelper::publishList();
		JToolBarHelper::unpublishList();
		JToolBarHelper::deleteList();
		JToolBarHelper::editList();
		JToolBarHelper::addNew();
	}
}
