<?php

defined( '_JEXEC' ) or die( 'Restricted access' );

class TableDailyMessage extends JTable
{
	var $id = null;
	var $message = null;
	var $date = null;
	var $published = null;
	
	function __construct(&$db)
	{
		parent::__construct( '#__dailymessage', 'id', $db );
		
		jimport('joomla.utilities.date');
		$now = new JDate();
		$this->set( 'date', $now->toMySQL() );
	}
}

