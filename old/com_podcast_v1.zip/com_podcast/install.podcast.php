<?php
function com_install() {

global $mosConfig_absolute_path;

include($mosConfig_absolute_path . "/administrator/components/com_podcast/" . "info.podcast.php");

}
?> 
