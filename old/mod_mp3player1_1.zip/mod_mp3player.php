<?

defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

global $mosConfig_live_site, $database;

	$query = "SELECT a.id"
	. "\n FROM #__components AS a"
	. "\n WHERE a.option = 'com_mp3player'"
	;
	$database->setQuery( $query );
	$id = $database->loadResult();

	$component = new mosComponent( $database );
	$component->load( $id );
	$params =& new mosParameters( $component->params );

	$playlistfile = $params->get('playlistfile', 'cache/mp3playlist.xml');

	if($playlistfile == "cache/mp3playlist.xml")
		createPlaylist("cache/mp3playlist.xml", $params);
?>
<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" width="<? echo $params->get('width', '500');  ?>" height="<? echo $params->get('height', '400');  ?>" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0">
  <param name="movie" value="<? echo $mosConfig_live_site; ?>/components/com_mp3player/mp3player.swf?playlist=<? echo $playlistfile; ?>" />
  <param name="quality" value="high" />
  <param name="wmode" value="transparent">
  <embed src="<? echo $mosConfig_live_site; ?>/components/com_mp3player/mp3player.swf?playlist=<? echo $playlistfile; ?>" quality="high" wmode="transparent"
width="<? echo $params->get('width', '500');  ?>" height="<? echo $params->get('height', '400');  ?>"     type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />
</object>
<?

function createPlaylist($file, &$params)
{
	global $database, $mosConfig_absolute_path;
	$database->SetQuery("SELECT * FROM #__mp3player ORDER BY ordering");
	$rows = $database->loadObjectList();
	
	$playlist = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
	$playlist .= "<player showDisplay=\"" . $params->get('showDisplay', 'yes') . "\" showPlaylist=\"" . $params->get('showPlaylist', 'no') . "\" autoStart=\"" . $params->get('autoStart', 'yes') . "\">";
	foreach($rows as $row)
	{
		$playlist .= "<song path=\"" . $row->mp3_filename . "\" title=\"" . $row->mp3_title . "\" />\n";
	}
	
	$playlist .= "</player>";
	
	$thefile = fopen($mosConfig_absolute_path . "/" . $file, "w+");
	fwrite($thefile, $playlist);
	fclose($thefile);
}


?>